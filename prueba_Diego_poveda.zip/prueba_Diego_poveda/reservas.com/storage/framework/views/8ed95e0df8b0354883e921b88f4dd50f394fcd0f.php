  

 <?php $__env->startSection('title'); ?>
 Crear Nueva Usuario
 <?php $__env->stopSection(); ?>

 <?php $__env->startSection('content'); ?>

 <?php echo Form::open(['url' => 'api.usuarios.usuarios','method' => 'POST']); ?>

 
 <div class="form-group">
 	<?php echo Form::text('nombre',null,['class'=>'form-control','placeholder' => 'Nombre']); ?> 	
 </div>
 <div class="form-group">
 	<?php echo Form::text('apellidos',null,['class'=>'form-control','placeholder' => 'Apellidos']); ?>

 </div>
 <div class="form-group">
 	<?php echo Form::text('identidad',null,['class'=>'form-control','placeholder' => 'Identidad']); ?>

 </div>
  <div class="form-group">
 	<?php echo Form::submit('Guardar Usuario',['class'=>'btn btn-primary']); ?>

 </div>
 <?php echo Form::close(); ?>

 <?php $__env->stopSection(); ?>
 

<?php echo $__env->make('template.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>