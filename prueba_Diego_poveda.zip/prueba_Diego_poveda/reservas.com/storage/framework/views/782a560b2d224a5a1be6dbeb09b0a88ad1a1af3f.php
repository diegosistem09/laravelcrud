  

 <?php $__env->startSection('title'); ?>
 LISTA DE TODAS LAS RESERVAS
 <?php $__env->stopSection(); ?>

 <?php $__env->startSection('content'); ?>
 <table class="table table-condensed">
 	<thead>
          <tr>
            <th>#</th>
            <th>Nombre</th>
            <th>Apellidos</th>
            <th>Fecha </th>
            <th>Estado</th>
            <th>Acciones</th>
          </tr>
        </thead>
        <tbody>

        	<?php $__currentLoopData = $reservas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reserva): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>:
        	<tr>
        		<td>  <?php echo e($reserva->id); ?>  </td>
        		<td>  <?php echo e($reserva->nombre); ?> </td>
        		<td>  <?php echo e($reserva->apellidos); ?> </td>
        		<td>  <?php echo e($reserva->fecha); ?> </td>
        		<td>  <?php echo e($reserva->estado); ?> </td>
        		<td>
        			<a href="<?php echo e(route('reserva.edit',$reserva->id)); ?>" class="btn btn-warning">
        				<span class="glyphicon glyphicon-remove-circle">Editar</span>
        			</a>
        			<a href="<?php echo e(route('reserva.destroy',$reserva->id)); ?>" class="btn btn-danger">
        				<span class="glyphicon glyphicon-remove-circle">Eliminar</span>
        			</a>
        		</td> 

        	</tr>
        	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
  
</table>
 <?php $__env->stopSection(); ?>


 

<?php echo $__env->make('template.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>