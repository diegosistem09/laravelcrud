  

 <?php $__env->startSection('title'); ?>
 Crear Nueva Reserva
 <?php $__env->stopSection(); ?>

 <?php $__env->startSection('content'); ?>

 <?php echo Form::open(['url' => 'api/reservas/save','method' => 'POST']); ?>

 
 <div class="form-group">
 	<?php echo Form::text('nombre',null,['class'=>'form-control','placeholder' => 'Nombre']); ?> 	
 </div>
 <div class="form-group">
 	<?php echo Form::text('apellidos',null,['class'=>'form-control','placeholder' => 'Apellidos']); ?>

 </div>
 <div class="form-group">
 	<?php echo Form::text('fecha',null,['class'=>'form-control','placeholder' => 'Fecha']); ?>

 </div>
  <div class="form-group">
 	<?php echo Form::text('numero_personas',null,['class'=>'form-control','placeholder' => 'Cantidad de personas']); ?>

 </div>
  <div class="form-group">
 	<?php echo Form::text('fila',null,['class'=>'form-control','placeholder' => '# Fila']); ?>

 </div>
 <div class="form-group">
 	<?php echo Form::label('select', 'Seleccione el numero de Fila', ['class' => ' control-label'] ); ?>

 </div>
 <div class="form-group">
 	<?php echo Form::select('select', ['1' => '1', '2' => '2', '3' => '3', '4' => '4','5'=>'5'],  'S', ['class' => 'form-control' ]); ?>

 </div>
 <div class="form-group">
 	<?php echo Form::text('columna',null,['class'=>'form-control','placeholder' => '#Columna']); ?>

 </div>
  <div class="form-group">
 	<?php echo Form::text('butaca',null,['class'=>'form-control','placeholder' => '# Butaca']); ?>

 	 <?php echo Form::hidden('estado', 1); ?>

 </div>
  <div class="form-group">
 	<?php echo Form::submit('Guardar Reserva',['class'=>'btn btn-primary']); ?>

 </div>
 <?php echo Form::close(); ?>

 <?php $__env->stopSection(); ?>
 

<?php echo $__env->make('template.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>