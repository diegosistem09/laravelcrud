<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title><?php echo $__env->yieldContent('title','default'); ?> | Administracion</title>
	<link rel="stylesheet"  href="<?php echo e(asset('plugins/bootstrap/css/bootstrap.css')); ?>">
</head>
<body>
	<?php echo $__env->make('template.menu.nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<section style="padding: 20mm">
	<?php echo $__env->yieldContent('content'); ?>
</section>


<script src="<?php echo e(asset('plugins/bootstrap/js/bootstrap.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/jquery/js/jquery-3.3.1.js')); ?>"></script>
</body>
</html>