  

 <?php $__env->startSection('title'); ?>
 Editar Reserva
 <?php $__env->stopSection(); ?>

 <?php $__env->startSection('content'); ?>
 
 <?php $__currentLoopData = $reserva; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $object): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php echo e($object->id); ?>


 <?php echo Form::model(['route' => 'api/reservas/update',$object->id ,'method' => 'PUT']); ?>

 <div class="form-group">
 	<?php echo Form::label('select', 'Nombre ', ['class' => ' control-label'] ); ?>

 </div>
 <div class="form-group">
 	<?php echo Form::text('nombre', $object->nombre,['class'=>'form-control']); ?> 	
 </div>
 <div class="form-group">
 	<?php echo Form::label('select', 'Apellidos', ['class' => ' control-label'] ); ?>

 </div>
 <div class="form-group">
 	<?php echo Form::text('apellidos',$object->apellidos,['class'=>'form-control','placeholder' => 'Apellidos']); ?>

 </div>
 <div class="form-group">
 	<?php echo Form::label('select', 'Fecha', ['class' => ' control-label'] ); ?>

 </div>
 <div class="form-group">
 	<?php echo Form::date('fecha', \Carbon\Carbon::now()); ?>

 </div>
 <div class="form-group">
 	<?php echo Form::label('select', 'Numero de personas', ['class' => ' control-label'] ); ?>

 </div>
  <div class="form-group">
 	<?php echo Form::text('numero_personas',$object->numero_personas,['class'=>'form-control','placeholder' => 'Cantidad de personas']); ?>

 </div>
  
  <div class="form-group">
 	<?php echo Form::label('select', 'Seleccione el numero de Fila', ['class' => ' control-label'] ); ?>

 </div>
 <div class="form-group">
 	<?php echo Form::select('fila', ['1' => '1', '2' => '2', '3' => '3', '4' => '4','5'=>'5'],  'S', ['class' => 'form-control' ]); ?>

 </div>

 <div class="form-group">
 	<?php echo Form::label('select', 'Seleccione la silla', ['class' => ' control-label'] ); ?>

 </div>
 <div class="form-group">
 	<?php echo Form::select('silla', ['1' => '1', '2' => '2', '3' => '3', '4' => '4','5'=>'5','6'=>'6','7'=>'7','8'=>'8','9'=>'9','10'=>'10'],  'S', ['class' => 'form-control' ]); ?>

 </div>
 <div class="form-group">
 	<?php echo Form::label('select', 'Estado de la Reserva', ['class' => ' control-label'] ); ?>

 </div>

  <div class="form-group">
 	<?php echo Form::text('estado',$object->estado,['class'=>'form-control','placeholder' => '# Butaca']); ?>

 	
 </div>
  <div class="form-group">
 	<?php echo Form::submit('Editar',['class'=>'btn btn-primary']); ?>

 </div>
 <?php echo Form::close(); ?>

 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
 <?php $__env->stopSection(); ?>
 

<?php echo $__env->make('template.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>