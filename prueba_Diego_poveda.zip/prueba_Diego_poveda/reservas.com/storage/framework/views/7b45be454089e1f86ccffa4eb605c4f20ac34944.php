  

 <?php $__env->startSection('title'); ?>
 LISTA DE TODAS LOS USUARIOS
 <?php $__env->stopSection(); ?>

 <?php $__env->startSection('content'); ?>
 <table class="table table-condensed">
 	<thead>
          <tr>
            <th>#</th>
            <th>Nombre</th>
            <th>Apellidos</th>
            <th>accion </th>
            
          </tr>
        </thead>
        <tbody>

        	<?php $__currentLoopData = $usuarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usuarios): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>:
        	<tr>
        		<td>  <?php echo e($usuarios->id); ?>  </td>
        		<td>  <?php echo e($usuarios->nombre); ?> </td>
        		<td>  <?php echo e($usuarios->apellidos); ?> </td>      	
        		<td>
            <!--  <a href="<?php echo e(route('usuarios.edit',$usuarios->id)); ?>" class="btn btn-warning">
                        <span class="glyphicon glyphicon-remove-circle">Editar</span>
                    </a>-->
                   <a href="<?php echo e(route('usuarios.destroy',$usuarios->id)); ?>" class="btn btn-danger">
                        <span class="glyphicon glyphicon-remove-circle">Eliminar</span>
                    </a>    
                </td>
        	</tr>
        	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
  
</table>
 <?php $__env->stopSection(); ?>


 

<?php echo $__env->make('template.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>