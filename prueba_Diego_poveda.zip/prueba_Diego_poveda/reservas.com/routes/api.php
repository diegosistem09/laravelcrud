<?php

use Illuminate\Http\Request;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::middleware('auth:api')->get('/user', function (Request $request) {
    return $request->user();
});

Route::get('reservas','ReservaController@index')->name('reserva.index');    
Route::get('reservas/index','ReservaController@index')->name('reserva.index');
Route::post('reservas/save','ReservaController@store')->name('reserva.store');
Route::get('reservas/create','ReservaController@create')->name('reserva.create');
Route::get('reservas/{reserva}/edit',['uses' => 'ReservaController@edit','as' => 'reserva.edit']);
Route::put('reservas/{reserva}/update',['uses' => 'ReservaController@update','as' => 'reserva.update']);
Route::get('reservas/{id}/destroy',['uses' => 'ReservaController@destroy','as' => 'reserva.destroy']);

/*usuarios route*/
Route::get('usuarios','UsuariosController@index')->name('usuarios.index');    
Route::post('usuarios/usuarios','UsuariosController@store')->name('usuarios.store');    
Route::get('usuarios/create','UsuariosController@create')->name('usuarios.create');
Route::get('usuarios/index','UsuariosController@show')->name('usuarios.show');
Route::get('usuarios/{reserva}/edit',['uses' => 'UsuariosController@edit','as' => 'usuarios.edit']);
Route::get('usuarios/{id}/destroy',['uses' => 'UsuariosController@destroy','as' => 'usuarios.destroy']);




