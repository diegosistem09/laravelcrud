 @extends('template.main') 

 @section('title')
 LISTA DE TODAS LAS RESERVAS
 @endsection

 @section('content')
 <table class="table table-condensed">
 	<thead>
          <tr>
            <th>#</th>
            <th>Nombre</th>
            <th>Apellidos</th>
            <th>Fecha </th>
            <th>Estado</th>
            <th>Acciones</th>
          </tr>
        </thead>
        <tbody>

        	@foreach($reservas as $reserva):
        	<tr>
        		<td>  {{ $reserva->id  }}  </td>
        		<td>  {{ $reserva->nombre }} </td>
        		<td>  {{ $reserva->apellidos }} </td>
        		<td>  {{ $reserva->fecha }} </td>
        		<td>  {{ $reserva->estado }} </td>
        		<td>
        			<a href="{{ route('reserva.edit',$reserva->id) }}" class="btn btn-warning">
        				<span class="glyphicon glyphicon-remove-circle">Editar</span>
        			</a>
        			<a href="{{ route('reserva.destroy',$reserva->id) }}" class="btn btn-danger">
        				<span class="glyphicon glyphicon-remove-circle">Eliminar</span>
        			</a>
        		</td> 

        	</tr>
        	@endforeach
        </tbody>
  
</table>
 @endsection


 
