 @extends('template.main') 

 @section('title')
 LISTA DE TODAS LOS USUARIOS
 @endsection

 @section('content')
 <table class="table table-condensed">
 	<thead>
          <tr>
            <th>#</th>
            <th>Nombre</th>
            <th>Apellidos</th>
            <th>accion </th>
            
          </tr>
        </thead>
        <tbody>

        	@foreach($usuarios as $usuarios):
        	<tr>
        		<td>  {{ $usuarios->id  }}  </td>
        		<td>  {{ $usuarios->nombre }} </td>
        		<td>  {{ $usuarios->apellidos }} </td>      	
        		<td>
            <!--  <a href="{{ route('usuarios.edit',$usuarios->id) }}" class="btn btn-warning">
                        <span class="glyphicon glyphicon-remove-circle">Editar</span>
                    </a>-->
                   <a href="{{ route('usuarios.destroy',$usuarios->id) }}" class="btn btn-danger">
                        <span class="glyphicon glyphicon-remove-circle">Eliminar</span>
                    </a>    
                </td>
        	</tr>
        	@endforeach
        </tbody>
  
</table>
 @endsection


 
