 @extends('template.main') 

 @section('title')
 Crear Nueva Usuario
 @endsection

 @section('content')

 {!! Form::open(['url' => 'api/usuarios/usuarios','method' => 'POST']) !!}
 
 <div class="form-group">
 	{!! Form::text('nombre',null,['class'=>'form-control','placeholder' => 'Nombre'])  !!} 	
 </div>
 <div class="form-group">
 	{!! Form::text('apellidos',null,['class'=>'form-control','placeholder' => 'Apellidos'])  !!}
 </div>
 <div class="form-group">
 	{!! Form::text('identidad',null,['class'=>'form-control','placeholder' => 'Identidad'])  !!}
 </div>
  <div class="form-group">
 	{!! Form::submit('Guardar Usuario',['class'=>'btn btn-primary'])  !!}
 </div>
 {!! Form::close() !!}
 @endsection
 
