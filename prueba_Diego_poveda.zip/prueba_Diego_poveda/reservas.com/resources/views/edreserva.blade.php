 @extends('template.main') 

 @section('title')
 Editar Reserva
 @endsection

 @section('content')
 
 @foreach ($reserva as $object)
    {{ $object->id }}

 {!! Form::model(['route' => 'api/reservas/update',$object->id ,'method' => 'PUT']) !!}
 <div class="form-group">
 	{!! Form::label('select', 'Nombre ', ['class' => ' control-label'] )  !!}
 </div>
 <div class="form-group">
 	{!! Form::text('nombre', $object->nombre,['class'=>'form-control'])  !!} 	
 </div>
 <div class="form-group">
 	{!! Form::label('select', 'Apellidos', ['class' => ' control-label'] )  !!}
 </div>
 <div class="form-group">
 	{!! Form::text('apellidos',$object->apellidos,['class'=>'form-control','placeholder' => 'Apellidos'])  !!}
 </div>
 <div class="form-group">
 	{!! Form::label('select', 'Fecha', ['class' => ' control-label'] )  !!}
 </div>
 <div class="form-group">
 	{!! Form::date('fecha', \Carbon\Carbon::now())  !!}
 </div>
 <div class="form-group">
 	{!! Form::label('select', 'Numero de personas', ['class' => ' control-label'] )  !!}
 </div>
  <div class="form-group">
 	{!! Form::text('numero_personas',$object->numero_personas,['class'=>'form-control','placeholder' => 'Cantidad de personas'])  !!}
 </div>
  
  <div class="form-group">
 	{!! Form::label('select', 'Seleccione el numero de Fila', ['class' => ' control-label'] )  !!}
 </div>
 <div class="form-group">
 	{!!  Form::select('fila', ['1' => '1', '2' => '2', '3' => '3', '4' => '4','5'=>'5'],  'S', ['class' => 'form-control' ]) !!}
 </div>

 <div class="form-group">
 	{!! Form::label('select', 'Seleccione la silla', ['class' => ' control-label'] )  !!}
 </div>
 <div class="form-group">
 	{!!  Form::select('silla', ['1' => '1', '2' => '2', '3' => '3', '4' => '4','5'=>'5','6'=>'6','7'=>'7','8'=>'8','9'=>'9','10'=>'10'],  'S', ['class' => 'form-control' ]) !!}
 </div>
 <div class="form-group">
 	{!! Form::label('select', 'Estado de la Reserva', ['class' => ' control-label'] )  !!}
 </div>

  <div class="form-group">
 	{!! Form::text('estado',$object->estado,['class'=>'form-control','placeholder' => '# Butaca'])  !!}
 	
 </div>
  <div class="form-group">
 	{!! Form::submit('Editar',['class'=>'btn btn-primary'])  !!}
 </div>
 {!! Form::close() !!}
 @endforeach
 @endsection
 
