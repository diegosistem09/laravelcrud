<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>@yield('title','default') | Administracion</title>
	<link rel="stylesheet"  href="{{ asset('plugins/bootstrap/css/bootstrap.css') }}">
</head>
<body>
	@include('template.menu.nav')
<section style="padding: 20mm">
	@yield('content')
</section>


<script src="{{ asset('plugins/bootstrap/js/bootstrap.js')  }}"></script>
<script src="{{ asset('plugins/jquery/js/jquery-3.3.1.js')  }}"></script>
</body>
</html>