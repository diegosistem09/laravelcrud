<ul class="nav nav-pills">
  <li class="nav-item">
    <a class="nav-link active" href="#">home</a>
  </li>
  <li class="nav-item">
    <a class="nav-link" href="reservas/create">Crear Reserva</a>
  </li>
  <li class="nav-item">
    <a class="nav-link" href="/reservas">Ver Reservas</a>
  </li>
  
</ul>