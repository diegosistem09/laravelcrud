 @extends('template.main') 

 @section('title')
 Crear Nueva Reserva
 @endsection

 @section('content')

 {!! Form::open(['url' => 'api/reservas/save','method' => 'POST']) !!}
 
 <div class="form-group">
 	{!! Form::text('nombre',null,['class'=>'form-control','placeholder' => 'Nombre'])  !!} 	
 </div>
 <div class="form-group">
 	{!! Form::text('apellidos',null,['class'=>'form-control','placeholder' => 'Apellidos'])  !!}
 </div>
 <div class="form-group">
 	{!! Form::text('fecha',null,['class'=>'form-control','placeholder' => 'Fecha'])  !!}
 </div>
  <div class="form-group">
 	{!! Form::text('numero_personas',null,['class'=>'form-control','placeholder' => 'Cantidad de personas'])  !!}
 </div>
  <div class="form-group">
 	{!! Form::text('fila',null,['class'=>'form-control','placeholder' => '# Fila'])  !!}
 </div>
 <div class="form-group">
 	{!! Form::label('select', 'Seleccione el numero de Fila', ['class' => ' control-label'] )  !!}
 </div>
 <div class="form-group">
 	{!!  Form::select('select', ['1' => '1', '2' => '2', '3' => '3', '4' => '4','5'=>'5'],  'S', ['class' => 'form-control' ]) !!}
 </div>
 <div class="form-group">
 	{!! Form::text('columna',null,['class'=>'form-control','placeholder' => '#Columna'])  !!}
 </div>
  <div class="form-group">
 	{!! Form::text('butaca',null,['class'=>'form-control','placeholder' => '# Butaca'])  !!}
 	 {!! Form::hidden('estado', 1) !!}
 </div>
  <div class="form-group">
 	{!! Form::submit('Guardar Reserva',['class'=>'btn btn-primary'])  !!}
 </div>
 {!! Form::close() !!}
 @endsection
 
