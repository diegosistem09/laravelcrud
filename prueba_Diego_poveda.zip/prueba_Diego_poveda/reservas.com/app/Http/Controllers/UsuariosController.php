<?php

namespace App\Http\Controllers;

use App\Usuarios;
use Illuminate\Http\Request;

class UsuariosController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {


        $usuarios = Usuarios::orderBy('id','ASC')->paginate(9);
        return view('usuarios.verusuarios')->with('usuarios',$usuarios);

    }

    public function miroute(Request $request){
        return view('usuarios.crearusuario');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create(Request $request)
    {
        
        return view('usuarios.crearusuario');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        
       $reserva = new usuarios();
       $reserva->nombre = $request-> input('nombre');
       $reserva->apellidos = $request-> input('apellidos');
       $reserva->identidad = $request-> input('identidad');
     
       $reserva->save();
       echo "<h4>Datos almacenados Correctamente </h4> <a href='../usuarios'>Crear nueva reserva</a> ";
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Usuarios  $usuarios
     * @return \Illuminate\Http\Response
     */
    public function show(Usuarios $usuarios)
    {
       return view('usuarios.index');
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Usuarios  $usuarios
     * @return \Illuminate\Http\Response
     */
    public function edit(Usuarios $usuarios)
    {
        
        $datauser = Reserva::find($usuarios);       
        return view('editarusuario')->with('usuario',$datauser);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Usuarios  $usuarios
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Usuarios $usuarios)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Usuarios  $usuarios
     * @return \Illuminate\Http\Response
     */
    public function destroy(Usuarios $id)
    {
        $usuariosdata = Usuarios::find($id);
        $usuariosdata->each->delete();

       return view('usuarios.usuario');

    }
}
