<?php

namespace App\Http\Controllers;

use App\Reserva;
use Illuminate\Http\Request;

class ReservaController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
       /*$reservas = Reserva::get();
       echo json_encode($reservas);*/
    
      // return view('reservas');
       $reservas = Reserva::orderBy('id','ASC')->paginate(9);

   
       return view('viewreservas')->with('reservas',$reservas);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('reservas');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {

       $reserva = new reserva();
       $reserva->nombre = $request-> input('nombre');
       $reserva->apellidos = $request-> input('apellidos');
       $reserva->numero_personas=$request->input( 'numero_personas');
       $reserva->fecha = $request-> input('fecha');
       $reserva->fila=$request->input('fila');
       $reserva->columna=$request->input('columna');
       $reserva->butaca=$request->input('butaca');
       $reserva->estado=$request->input('estado');
       $reserva->save();
       echo "<h4>Datos almacenados Correctamente </h4> <a href='reservas'>Crear nueva reserva</a> ";
       //return redirect('api/reservas');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Reserva  $reserva
     * @return \Illuminate\Http\Response
     */
    public function show(Reserva $reserva)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Reserva  $reserva
     * @return \Illuminate\Http\Response
     */
    public function edit(Reserva $reserva)
    {

        $datareserva = Reserva::find($reserva);       
        return view('edreserva')->with('reserva',$datareserva);

    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Reserva  $reserva
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Reserva $reserva )
    {
       $dato_reserva = Reserva::find(6);
      // $dato_reserva->nombre = $request->get('nombre');
      
      // $dato_reserva->save();

       dd($dato_reserva);



    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Reserva  $reserva
     * @return \Illuminate\Http\Response
     */
    public function destroy(Reserva $id)
    {
       $reserva = Reserva::find($id);
       $reserva->each->delete();
       return view('reservas');
    }
}
